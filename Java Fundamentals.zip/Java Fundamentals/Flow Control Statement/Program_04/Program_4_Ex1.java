
public class Program_4_Ex1 {
	public static void main(String[] args) {
		char ch1 = 's';
		char ch2 = 'e';
		
		if(ch1 > ch2)
		{
			System.out.println(ch2 + "," + ch1);
		}
		else {
			System.out.println(ch1 + "," + ch2);
		}
	}
}
