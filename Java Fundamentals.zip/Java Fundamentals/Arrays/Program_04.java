
public class Program_04 {
	public static void main(String[] args)
	{
		int[] arr= {67,78,87,97,99};
		for(int i=0; i<arr.length; i++)
		{
			System.out.print((char)arr[i] + " ");
		}
	}
}
