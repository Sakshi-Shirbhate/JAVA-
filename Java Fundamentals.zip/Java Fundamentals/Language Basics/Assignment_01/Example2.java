
public class Example2 {
	public static void main(String[] args) {
		System.out.println(args[0]+" Technologies "+args[1]);
	}
}
